import boto3
import logging

logger = logging.getLogger(__name__)


class S3Operations:
    def __init__(self, region):
        self.s3_client = boto3.client('s3', region_name=region)
        
    def create_s3_bucket(self, group_name):
        bucket_name = f"{group_name.lower()}-bucket"
        try:
            self.s3_client.create_bucket(Bucket=bucket_name)
            logger.info(f"S3 bucket {bucket_name} created successfully.")
        except self.s3_client.exceptions.BucketAlreadyExists as e:
            logger.warning(f"Bucket {bucket_name} already exists.")
        except Exception as e:
            logger.error(f"Error creating S3 bucket: {e}")
