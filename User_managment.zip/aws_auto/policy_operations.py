import json
import logging

logger = logging.getLogger(__name__)


class PolicyOperations:
    def __init__(self, iam_client):
        self.iam_client = iam_client

    def load_policy_from_file(self, policy_file_path, group_name, region):
        try:
            with open(policy_file_path, 'r') as policy_file:
                policy = json.load(policy_file)
            policy_str = json.dumps(policy)
            policy_str = policy_str.replace(
                "GROUP_NAME_PLACEHOLDER", group_name)
            policy_str = policy_str.replace("REGION_PLACEHOLDER", region)
            return json.loads(policy_str)
        except FileNotFoundError:
            logger.errozr(f"Policy file {policy_file_path} not found.")
            return None
        except json.JSONDecodeError as e:
            logger.error(f"Error decoding JSON from policy file: {e}")
            return None

    def create_and_attach_policy(self, group_name, policy_document):
        try:
            policy_response = self.iam_client.create_policy(
                PolicyName=f"{group_name}_policy",
                PolicyDocument=json.dumps(policy_document)
            )
            policy_arn = policy_response['Policy']['Arn']

            self.iam_client.attach_group_policy(
                GroupName=group_name,
                PolicyArn=policy_arn
            )
            logger.info(f"Policy attached to group {group_name} successfully.")
        except Exception as e:
            logger.error(f"Error attaching policy: {e}")
