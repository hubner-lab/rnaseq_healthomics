import boto3
import logging

logger = logging.getLogger(__name__)


class IAMOperations:
    def __init__(self, region):
        self.iam_client = boto3.client('iam', region_name=region)

    def create_iam_group(self, group_name):
        try:
            self.iam_client.create_group(GroupName=group_name)
            logger.info(f"Group {group_name} created successfully.")
        except self.iam_client.exceptions.EntityAlreadyExistsException:
            logger.warning(f"Group {group_name} already exists.")

    def create_iam_user(self, user_name):
        try:
            self.iam_client.create_user(UserName=user_name)
            logger.info(f"User {user_name} created successfully.")
        except self.iam_client.exceptions.EntityAlreadyExistsException:
            logger.warning(f"User {user_name} already exists.")

    def add_user_to_group(self, user_name, group_name):
        try:
            self.iam_client.add_user_to_group(
                GroupName=group_name, UserName=user_name)
            logger.info(f"Added user {user_name} to group {group_name}.")
        except Exception as e:
            logger.error(f"Error adding user to group: {e}")

    def list_users(self):
        try:
            response = self.iam_client.list_users()
            users = response['Users']
            return users
        except Exception as e:
            logger.error(f"Error listing users: {e}")
            return []

    def list_groups(self):
        try:
            response = self.iam_client.list_groups()
            groups = response['Groups']
            return groups
        except Exception as e:
            logger.error(f"Error listing groups: {e}")
            return []

    def list_groups_for_user(self, user_name):
        try:
            response = self.iam_client.list_groups_for_user(UserName=user_name)
            groups = response['Groups']
            return groups
        except Exception as e:
            logger.error(f"Error listing groups for user {user_name}: {e}")
            return []

    def remove_user_from_group(self, user_name, group_name):
        try:
            self.iam_client.remove_user_from_group(
                GroupName=group_name, UserName=user_name)
            logger.info(f"Removed user {user_name} from group {group_name}.")
        except Exception as e:
            logger.error(f"Error removing user from group: {e}")

    def delete_user(self, user_name):
        try:
            self.iam_client.delete_user(UserName=user_name)
            logger.info(f"Deleted user {user_name} successfully.")
        except Exception as e:
            logger.error(f"Error deleting user {user_name}: {e}")
