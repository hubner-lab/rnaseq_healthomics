import configparser
import logging

from aws_auto.iam_operations import IAMOperations
from aws_auto.s3_operations import S3Operations
from aws_auto.policy_operations import PolicyOperations

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def load_config():
    config = configparser.ConfigParser()
    config.read('./config/config.ini')
    return config


def print_menu(menu_options):
    for key, value in menu_options.items():
        print(f"{key}. {value}")


def get_user_choice(menu_options):
    choice = input("Please select an option: ")
    if choice in menu_options:
        return choice
    else:
        print("Invalid option, please try again.")
        return None


def handle_existing_groups(iam_ops, policy_ops, s3_ops, region, policy_file_path):
    menu_options = {
        '1': "Show users and their groups",
        '2': "Show groups",
        '3': "Create a user in a group",
        '4': "Delete user",
        '5': "Change user group",
        '0': "Back"
    }

    while True:
        print("\nExisting Groups Menu")
        print_menu(menu_options)
        choice = get_user_choice(menu_options)

        if choice == '1':
            users = iam_ops.list_users()
            for user in users:
                user_name = user['UserName']
                groups = iam_ops.list_groups_for_user(user_name)
                group_names = [group['GroupName'] for group in groups]
                print(f"User {user_name} belongs to groups: {
                      ', '.join(group_names)}")
        elif choice == '2':
            groups = iam_ops.list_groups()
            for group in groups:
                print(f"Group: {group['GroupName']}")
        elif choice == '3':
            user_name = input("Enter new user name: ")
            groups = iam_ops.list_groups()
            for i, group in enumerate(groups):
                print(f"{i + 1}. {group['GroupName']}")
            group_index = int(
                input("Enter the number of the group to add the user to: ")) - 1
            group_name = groups[group_index]['GroupName']
            iam_ops.create_iam_user(user_name)
            iam_ops.add_user_to_group(user_name, group_name)
            print(f"User {user_name} created and added to group {group_name}.")
        elif choice == '4':
            user_name = input("Enter the user name to delete: ")
            iam_ops.delete_user(user_name)
            print(f"User {user_name} deleted successfully.")
        elif choice == '5':
            user_name = input("Enter the user name to move: ")
            old_groups = iam_ops.list_groups_for_user(user_name)
            for i, group in enumerate(old_groups):
                print(f"{i + 1}. {group['GroupName']}")
            old_group_index = int(
                input("Enter the number of the old group to remove the user from: ")) - 1
            old_group_name = old_groups[old_group_index]['GroupName']
            iam_ops.remove_user_from_group(user_name, old_group_name)
            groups = iam_ops.list_groups()
            for i, group in enumerate(groups):
                print(f"{i + 1}. {group['GroupName']}")
            new_group_index = int(
                input("Enter the number of the new group to add the user to: ")) - 1
            new_group_name = groups[new_group_index]['GroupName']
            iam_ops.add_user_to_group(user_name, new_group_name)
            print(f"User {user_name} moved from group {
                  old_group_name} to group {new_group_name}.")
        elif choice == '0':
            break


def handle_create_new_group(iam_ops, policy_ops, s3_ops, region, policy_file_path):
    group_name = input("Enter the new group name: ")
    iam_ops.create_iam_group(group_name)
    s3_ops.create_s3_bucket(group_name)
    policy_document = policy_ops.load_policy_from_file(
        policy_file_path, group_name, region)
    if policy_document:
        policy_ops.create_and_attach_policy(group_name, policy_document)
    print(
        f"Group {group_name} created successfully with S3 bucket and policy attached.")

    add_user_choice = input(f"Do you want to add a user to the group {
                            group_name}? (y/n): ").lower()
    if add_user_choice == 'y':
        user_name = input("Enter the new user name: ")
        iam_ops.create_iam_user(user_name)
        iam_ops.add_user_to_group(user_name, group_name)
        print(f"User {user_name} created and added to group {group_name}.")


def main():
    config = load_config()
    region = config['aws']['region']
    policy_file_path = config['files']['policy_file']

    iam_ops = IAMOperations(region)
    s3_ops = S3Operations(region)
    policy_ops = PolicyOperations(iam_ops.iam_client)

    main_menu_options = {
        '1': "Manage existing groups",
        '2': "Create new user group",
        '0': "Exit"
    }

    while True:
        print("\nMain Menu")
        print_menu(main_menu_options)
        choice = get_user_choice(main_menu_options)

        if choice == '1':
            handle_existing_groups(iam_ops, policy_ops,
                                   s3_ops, region, policy_file_path)
        elif choice == '2':
            handle_create_new_group(
                iam_ops, policy_ops, s3_ops, region, policy_file_path)
        elif choice == '0':
            print("Exiting...")
            break


if __name__ == "__main__":
    main()
